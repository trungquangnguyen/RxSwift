//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift

exampleOf("PublishSubject") {
    let subject = PublishSubject<String>()
    
    subject.subscribe {
        print($0)
    }
    
    enum Error: ErrorType {
        case Test
    }
    
    subject.on(.Next("Hello"))
//    subject.onCompleted()
//    subject.onError(Error.Test)
    subject.onNext("World")
    
    let newSubscription = subject.subscribeNext {
        print("New subscription:", $0)
    }
    
    subject.onNext("What's up?")
    
    newSubscription.dispose()
    subject.onNext("Still there?")
}

exampleOf("BehaviorSubject") {
    let subject = BehaviorSubject(value: "a")
    
    let firstSubscription = subject.subscribeNext {
        print(#line, $0)
    }
    
    subject.onNext("b")
    
    let secondSubscription = subject.subscribeNext {
        print(#line, $0)
    }
}

exampleOf("ReplaySubject") {
    let subject = ReplaySubject<Int>.create(bufferSize: 3)
    
    subject.onNext(1)
    subject.onNext(2)
    subject.onNext(3)
    subject.onNext(4)
    
    subject.subscribeNext {
        print($0)
    }
}

exampleOf("Variable") {
    let disposeBag = DisposeBag()
    let variable = Variable("A")
    
    variable.asObservable()
        .subscribeNext { print($0) }
        .addDisposableTo(disposeBag)
    
    variable.value = "B"
}
