//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift

exampleOf("filter") {
    let disposeBag = DisposeBag()
    let numbers = Observable.generate(initialState: 1, condition: { $0 < 101 }, iterate: { $0 + 1 })
    
    numbers.filter { number in
        guard number > 1 else { return false }
        var isPrime = true
        
        (2..<number).forEach {
            if number % $0 == 0 {
                isPrime = false
            }
        }
        
        return isPrime
        }
        .toArray()
        .subscribeNext { print($0) }
}

exampleOf("distinctUntilChanged") {
    let disposeBag = DisposeBag()
    let searchString = Variable("")
    
    searchString.asObservable()
        .map { $0.lowercaseString }
        .distinctUntilChanged()
        .subscribeNext { print($0) }
        .addDisposableTo(disposeBag)
    
    searchString.value = "APPLE"
    searchString.value = "apple"
    searchString.value = "Banana"
    searchString.value = "APPLE"
}

exampleOf("takeWhile") {
    let disposeBag = DisposeBag()
    let numbers = [1, 2, 3, 4, 3, 2, 1].toObservable()
    
    numbers.takeWhile { $0 < 4 }
        .subscribeNext { print($0) }
        .addDisposableTo(disposeBag)
}

