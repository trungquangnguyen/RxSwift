//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift

exampleOf("doOnNext") {
    let disposeBag = DisposeBag()
    
    let fahrenheitTemps = [-40, 0, 32, 70, 212].toObservable()
    
    fahrenheitTemps
        .doOnNext {
            $0 * $0
        }
        .doOnNext {
            print("\($0)℉ = ", terminator: "")
        }
        .map {
            Double($0 - 32) * 5/9.0
        }
        .subscribeNext {
            print(String(format: "%.1f℃", $0))
        }
        .addDisposableTo(disposeBag)
}
