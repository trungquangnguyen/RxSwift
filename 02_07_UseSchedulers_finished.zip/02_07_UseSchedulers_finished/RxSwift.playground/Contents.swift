//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift

let imageView = UIImageView(frame: CGRectMake(0.0, 0.0, 128.0, 128.0))
XCPlaygroundPage.currentPage.liveView = imageView

let swift = UIImage(named: "Swift")!
let swiftImageData = UIImagePNGRepresentation(swift)!
let rx = UIImage(named: "Rx")!
let rxImageData = UIImagePNGRepresentation(rx)!

let disposeBag = DisposeBag()

let imageDataSubject = PublishSubject<NSData>()

let scheduler = ConcurrentDispatchQueueScheduler(globalConcurrentQueueQOS: .Background)

let myQueue = dispatch_queue_create("com.scotteg.myConcurrentQueue", DISPATCH_QUEUE_CONCURRENT)
let scheduler2 = SerialDispatchQueueScheduler(queue: myQueue, internalSerialQueueName: "com.scotteg.mySerialQueue")

let operationQueue = NSOperationQueue()
operationQueue.qualityOfService = .Background
let scheduler3 = OperationQueueScheduler(operationQueue: operationQueue)

imageDataSubject
    .observeOn(scheduler3)
    .map {
        UIImage(data: $0)
    }
    .observeOn(MainScheduler.instance)
    .subscribeNext {
        imageView.image = $0
    }
    .addDisposableTo(disposeBag)

imageDataSubject.onNext(swiftImageData)
imageDataSubject.onNext(rxImageData)
