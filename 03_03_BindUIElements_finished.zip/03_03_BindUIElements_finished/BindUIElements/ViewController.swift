//
//  ViewController.swift
//  BindUIElements
//
//  Created by Scott Gardner on 6/1/16.
//  Copyright © 2016 Scott Gardner. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
    
    @IBOutlet weak var tapGestureRecognizer: UITapGestureRecognizer!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textFieldLabel: UILabel!
    @IBOutlet weak var textView: TextView!
    @IBOutlet weak var textViewLabel: UILabel!
    @IBOutlet weak var button: Button!
    @IBOutlet weak var buttonLabel: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var segmentedControlLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var aSwitch: UISwitch!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var stepperLabel: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var datePickerLabel: UILabel!
    
    let disposeBag = DisposeBag()
    
    lazy var dateFormatter: NSDateFormatter = {
        let formatter = NSDateFormatter()
        formatter.dateStyle = .MediumStyle
        formatter.timeStyle = .ShortStyle
        return formatter
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tapGestureRecognizer.rx_event.asDriver()
            .driveNext { [unowned self] _ in
                self.view.endEditing(true)
            }
            .addDisposableTo(disposeBag)
        
        textField.rx_text.asDriver()
            .drive(textFieldLabel.rx_text)
//            .driveNext { [unowned self] in
//                self.textFieldLabel.rx_text.onNext($0)
//            }
            .addDisposableTo(disposeBag)
        
        textView.rx_text
            .bindNext { [unowned self] in
//                self.textViewLabel.rx_text.onNext("Character count: \($0.characters.count)")
                self.textViewLabel.text = "Character count: \($0.characters.count)"
            }
            .addDisposableTo(disposeBag)
        
        button.rx_tap.asDriver()
            .driveNext { [unowned self] in
                self.buttonLabel.text! += "Tapped! "
                self.view.endEditing(true)
                UIView.animateWithDuration(0.3) {
                    self.view.layoutIfNeeded()
                }
            }
            .addDisposableTo(disposeBag)
        
        segmentedControl.rx_value.asDriver()
            .skip(1)
            .driveNext { [unowned self] in
                self.segmentedControlLabel.text = "Selected segment: \($0)"
                UIView.animateWithDuration(0.3) {
                    self.view.layoutIfNeeded()
                }
            }
            .addDisposableTo(disposeBag)
        
        slider.rx_value.asDriver()
            .drive(progressView.rx_progress)
            .addDisposableTo(disposeBag)
        
        aSwitch.rx_value.asDriver()
            .map { !$0 }
            .drive(activityIndicator.rx_hidden)
            .addDisposableTo(disposeBag)
        
        aSwitch.rx_value.asDriver()
            .drive(activityIndicator.rx_animating)
            .addDisposableTo(disposeBag)
        
        stepper.rx_value.asDriver()
            .map { String(Int($0)) }
            .drive(stepperLabel.rx_text)
            .addDisposableTo(disposeBag)
        
        datePicker.rx_date.asDriver()
            .map { [unowned self] in
                self.dateFormatter.stringFromDate($0) ?? ""
            }
            .driveNext { [unowned self] in
                self.datePickerLabel.text = "Selected date: \($0)"
            }
            .addDisposableTo(disposeBag)
    }
    
}
