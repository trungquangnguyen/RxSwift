//
//  ViewController.swift
//  BindUIElements
//
//  Created by Scott Gardner on 6/1/16.
//  Copyright © 2016 Scott Gardner. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
    
    @IBOutlet weak var tapGestureRecognizer: UITapGestureRecognizer!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var button: Button!
    
    let disposeBag = DisposeBag()
    let buttonTapped = PublishSubject<String>()
    let textFieldText = Variable("")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tapGestureRecognizer.rx_event.asDriver()
            .driveNext { [unowned self] _ in
                self.view.endEditing(true)
            }
            .addDisposableTo(disposeBag)
        
        textField.rx_text
            .bindTo(textFieldText)
            .addDisposableTo(disposeBag)
        
        textFieldText.asObservable()
            .subscribeNext { print($0) }
            .addDisposableTo(disposeBag)
        
        button.rx_tap
            .map { "Tapped! " }
            .bindTo(buttonTapped)
            .addDisposableTo(disposeBag)
        
        buttonTapped
            .subscribeNext { print($0) }
            .addDisposableTo(disposeBag)
    }
    
}
