//
//  Cell.swift
//  BindCollectionViews
//
//  Created by Scott Gardner on 6/3/16.
//  Copyright © 2016 Scott Gardner. All rights reserved.
//

import UIKit

class Cell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
}
