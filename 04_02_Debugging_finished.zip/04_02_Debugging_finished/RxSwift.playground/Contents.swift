//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift

func sampleWithPublish() {
    let interval = Observable<Int>.interval(1, scheduler: MainScheduler.instance).publish()
    
    interval
        .debug("1st")
        .subscribe { _ in }
    
    delay(2) {
        interval.connect()
    }
    
    let disposeBag = DisposeBag()
    delay(4) {
        _ = interval
            .debug("2nd")
            .subscribe { _ in }
            .addDisposableTo(disposeBag)
    }
}

//sampleWithPublish()

exampleOf("resourceCount") {
    print(RxSwift.resourceCount)
    
    let disposeBag = DisposeBag()
    
    print(RxSwift.resourceCount)
    
    let observable = Observable.just("Hello, world!")
    
    print(RxSwift.resourceCount)
    
    observable
        .subscribeNext { _ in
            print(RxSwift.resourceCount)
        }
        .addDisposableTo(disposeBag)
    
    print(RxSwift.resourceCount)
}

print(RxSwift.resourceCount)
