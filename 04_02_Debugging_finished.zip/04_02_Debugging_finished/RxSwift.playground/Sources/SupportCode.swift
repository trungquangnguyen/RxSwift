import Foundation

public func exampleOf(description: String, @noescape action: Void -> Void) {
    print("\n--- Example of:", description, "---")
    action()
}

public func delay(delay: UInt64, closure: Void -> Void) {
    dispatch_after(
        dispatch_time(
            DISPATCH_TIME_NOW,
            Int64(delay * NSEC_PER_SEC)
        ),
        dispatch_get_main_queue(),
        closure)
}
