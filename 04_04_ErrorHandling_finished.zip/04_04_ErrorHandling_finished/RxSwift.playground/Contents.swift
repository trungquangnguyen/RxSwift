//: Please build the scheme 'RxSwiftPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import RxSwift
import RxCocoa

exampleOf("catchErrorJustReturn") {
    let disposeBag = DisposeBag()
    
    let sequenceThatFails = PublishSubject<String>()
    sequenceThatFails.catchErrorJustReturn("😊")
        .subscribe { print($0) }
        .addDisposableTo(disposeBag)
    
    sequenceThatFails.onNext("Hello, world!")
    sequenceThatFails.onError(Error.Test)
}

exampleOf("catchError") {
    let disposeBag = DisposeBag()
    
    let sequenceThatFails = PublishSubject<String>()
    let recoverySequence = PublishSubject<String>()
    
    sequenceThatFails
        .catchError {
            print("Error:", $0)
            return recoverySequence
        }
        .subscribe { print($0) }
    
    sequenceThatFails.onNext("Hello, again")
    sequenceThatFails.onError(Error.Test)
    sequenceThatFails.onNext("Still there?")
    
    recoverySequence.onNext("Don't worry, I've got this!")
}

exampleOf("retry") {
    let disposeBag = DisposeBag()
    
    var count = 1
    
    let sequenceThatErrors = Observable<Int>.create { o in
        o.onNext(1)
        o.onNext(2)
        
        if count == 1 {
            o.onError(Error.Test)
            print("Error encountered")
            count += 1
        }
        
        o.onNext(3)
        o.onCompleted()
        
        return NopDisposable.instance
    }
    
    sequenceThatErrors
        .retry()
        .subscribe { print($0) }
        .addDisposableTo(disposeBag)
}

exampleOf("retry:maxAttemptCount:") {
    let disposeBag = DisposeBag()
    
    var count = 1
    
    let sequenceThatErrors = Observable<Int>.create { o in
        o.onNext(1)
        o.onNext(2)
        
        if count < 5 {
            o.onError(Error.Test)
            print("Error encountered")
            count += 1
        }
        
        o.onNext(3)
        o.onCompleted()
        
        return NopDisposable.instance
    }
    
    sequenceThatErrors
        .retry(3)
        .subscribe { print($0) }
        .addDisposableTo(disposeBag)
}

exampleOf("Driver onErrorJustReturn") {
    let disposeBag = DisposeBag()
    
    let subject = PublishSubject<Int>()
    
    subject.asDriver(onErrorJustReturn: 1000)
        .driveNext { print($0) }
        .addDisposableTo(disposeBag)
    
    subject.onNext(1)
    subject.onNext(2)
    
    subject.onError(Error.Test)
    
    subject.onNext(3)
}

exampleOf("Driver onErrorDriveWith") {
    let disposeBag = DisposeBag()
    
    let subject = PublishSubject<Int>()
    let recoverySubject = PublishSubject<Int>()
    
    subject.asDriver(onErrorDriveWith: recoverySubject.asDriver(onErrorJustReturn: 1000))
        .driveNext { print($0) }
        .addDisposableTo(disposeBag)
    
    subject.onNext(1)
    subject.onNext(2)
    
    subject.onError(Error.Test)
    
    subject.onNext(3)
    
    recoverySubject.onNext(10)
}

exampleOf("Driver onErrorRecover") {
    let disposeBag = DisposeBag()
    
    let subject = PublishSubject<Int>()
    
    subject.asDriver {
        print("Error:", $0)
        return Driver.just(1000)
        }
        .driveNext { print($0) }
        .addDisposableTo(disposeBag)
    
    subject.onNext(1)
    subject.onNext(2)
    
    subject.onError(Error.Test)
    
    subject.onNext(3)
}
