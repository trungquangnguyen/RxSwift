//
//  Repository.swift
//  Networking
//
//  Created by Scott Gardner on 6/6/16.
//  Copyright © 2016 Scott Gardner. All rights reserved.
//

import Foundation

struct Repository {
    
    let name: String
    let url: String
    
}
