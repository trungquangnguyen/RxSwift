//
//  ViewModel.swift
//  Networking
//
//  Created by Scott Gardner on 6/6/16.
//  Copyright © 2016 Scott Gardner. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

struct ViewModel {
    
    let searchText = Variable("")
    let disposeBag = DisposeBag()
    
    lazy var data: Driver<[Repository]> = {
        return self.searchText.asObservable()
            .throttle(0.3, scheduler: MainScheduler.instance)
            .distinctUntilChanged()
            .flatMapLatest {
                self.getRepositories($0)
            }
            .asDriver(onErrorJustReturn: [])
    }()
    
    func getRepositories(gitHubID: String) -> Observable<[Repository]> {
        guard !gitHubID.isEmpty,
            let url = NSURL(string: "https://api.github.com/users/\(gitHubID)/repos")
            else { return Observable.just([]) }
        
        return NSURLSession.sharedSession()
            .rx_JSON(NSURLRequest(URL: url))
            .retry(3)
            //        .catchErrorJustReturn([])
            //        .observeOn(ConcurrentDispatchQueueScheduler(globalConcurrentQueueQOS: .Background))
            .map {
                var repositories = [Repository]()
                
                if let items = $0 as? [[String: AnyObject]] {
                    items.forEach {
                        guard let name = $0["name"] as? String,
                            url = $0["html_url"] as? String
                            else { return }
                        repositories.append(Repository(name: name, url: url))
                    }
                }
                
                return repositories
        }
    }
}
